#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *pt;

    *pt = 5; //Error: Dereferenced uninitialized pointer

    return 0;
}
