#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 0;

    int *pvalue = &value;

    printf("Enter any value:");
    scanf("%d", pvalue);

    printf("Output is:%d\n", value);

    printf("Output is:%d", *pvalue);

    return 0;
}
