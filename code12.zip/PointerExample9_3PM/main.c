#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int value = 10;

    const int *const pvalue = &value; //address can't be changed //constant pointer

   // *pvalue = 20; //value can't be changed

   // int item = 20;

    //pvalue = &item; //Error: assignment read-only variable

    value= 20; //normal value can't be changed

    return 0;
}
