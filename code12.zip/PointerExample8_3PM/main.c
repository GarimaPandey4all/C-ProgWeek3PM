#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 10;

    int *const pvalue = &value; //address can't be changed //constant pointer

    *pvalue = 20;

    int item = 20;

    pvalue = &item; //Error: assignment read-only variable

    return 0;
}
