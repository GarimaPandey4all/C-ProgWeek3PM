#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 10;

    const int *pvalue = &value; //value can't be changed

    *pvalue = 20;

    return 0;
}
