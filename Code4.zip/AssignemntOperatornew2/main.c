#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum=0, a;

    printf("Enter any value for a:");
    scanf("%d", &a);

    sum += a; //sum = sum + a;

    printf("Sum is: %d", sum);

    return 0;
}
