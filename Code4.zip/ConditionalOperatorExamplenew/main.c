#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number, remainder;

    printf("Enter any number:");
    scanf("%d", &number);

    remainder = number % 2;

    (remainder == 0)?printf("Even") : printf("Odd");

//    if(remainder == 0)
//        printf("The number is Even");
//
//    else
//        printf("The number is Odd");

    return 0;
}
