#include <stdio.h>
#include <stdlib.h>

int main()
{
    float marks[10];
    float average = 0.0f;
    float sum = 0.0f;
    const int count = 10;
    int i;
    float percentage = 0.0f;

    printf("Enter Ten Grades:\n");
    for(i=0; i<count;i++)
    scanf("%f", &marks[i]);

    for(i=0; i<count;i++)
    {
        sum += marks[i];
    }
    printf("Sum of ten Grades: %.2f", sum);

    average = sum / count;

    printf("\nAverage is: %.2f", average);

    percentage = (sum /1000) * 100;

    printf("\nPercentage is: %.2f", percentage);

    if(percentage > 50 && percentage < 60)
        printf("\nD Grade");

    else if(percentage > 60 && percentage < 70)
        printf("\n\nC Grade");

    else if(percentage > 70 && percentage < 80)
        printf("\n\nB Grade");

    else if(percentage > 80 && percentage < 100)
        printf("\n\nA Grade....Awarded");

    else
        printf("\n\nOtherwise Fail....\n");

    return 0;
}
