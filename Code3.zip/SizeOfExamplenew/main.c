#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    float b;
    char c;
    double d;
    long double e;

    printf("SizeOf of int: %u", sizeof(a));

    printf("\nSizeOf of float: %u", sizeof(b));

    printf("\nSizeOf of char: %u", sizeof(c));

    printf("\nSizeOf of double: %u", sizeof(d));
    printf("\nSizeOf of long double: %u", sizeof(e));

    return 0;
}
