#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, largest;

    printf("Enter value for variable a:");
    scanf("%d", &a);

    printf("Enter value for variable b:");
    scanf("%d", &b);

    printf("Enter value for variable c:");
    scanf("%d", &c);

    largest = (a>b) ? (a>c?a:c): (b>c?b:c); // a= 10, b=5, c=25

    printf("Largest number is: %d", largest);

    return 0;
}
