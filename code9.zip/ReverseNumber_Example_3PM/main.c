#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, reverse=0;

    printf("Enter any number:");
    scanf("%d", &n);

    while(n>0)
    {
        r = n%10; //giving remainder 5225, 52
        reverse = reverse * 10 + r; // 5, 52
        n = n/10; // giving quotient 522, 52
    }

    printf("Reverse number is:%d", reverse);

    return 0;
}
