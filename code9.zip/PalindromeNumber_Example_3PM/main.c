#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, sum=0, temp;

    printf("Enter any number to check whether the number is Palindrome or not?");
    scanf("%d", &n);

    temp = n;

    while(n>0)
    {
        r = n%10; //giving remainder 5225, 52
        sum = sum * 10 + r; // 5, 52
        n = n/10; // giving quotient 522, 52
    }

    n= temp;

    (n==sum)? printf("Number is Palindrome") : printf("Not a Palindrome Number");

    return 0;
}
