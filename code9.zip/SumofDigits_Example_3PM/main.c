#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, sum=0;

    printf("Enter any number:");
    scanf("%d", &n);

    while(n>0)
    {
        r = n%10; //giving remainder 5225, 52
        sum = sum + r; // 5, 52
        n = n/10; // giving quotient 522, 52
    }

    printf("Sum of Digits are:%d", sum);

    return 0;
}
