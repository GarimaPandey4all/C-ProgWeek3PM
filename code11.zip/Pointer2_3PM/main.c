#include <stdio.h>
#include <stdlib.h>

int main()
{
    int result=0, number=15;
    int *pnumber = NULL;

    pnumber =&number;

    result = *pnumber + 5;

    printf("Result is:%d", result);

    return 0;
}
