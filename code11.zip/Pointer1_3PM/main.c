#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number=99;

    int *pnumber = &number;

    printf("Address of: %d\n", pnumber);

    printf("Value of: %d", *pnumber);

    return 0;
}
