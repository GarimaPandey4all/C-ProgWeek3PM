#include <stdio.h>
#include <stdlib.h>

int main()
{
    int count=10, x;
    int *ptr = NULL;

    ptr = &count;

    x = *ptr;

    printf("count is=%d and x=%d", count, x);

    return 0;
}
