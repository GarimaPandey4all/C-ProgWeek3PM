#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Oper;
    int A, B, C;

    printf("Enter any Operator:");
    scanf("%c", &Oper);

    printf("Enter value for Operand1:");
    scanf("%d", &A);

    printf("Enter value for Operand2:");
    scanf("%d", &B);

    switch(Oper)
    {
    case '+':
        printf("Addition of Two Numbers: %d", A + B);
        break;

    case '-':
        printf("Subtraction of Two Numbers: %d", A - B);
        break;

    case '*':
        printf("Multiply of Two Numbers: %d", A * B);
        break;

    case '/':
        printf("Division of Two Numbers: %d", A / B);
        break;

    case '%':
        printf("Modulus of Two Numbers: %d", C = A % B);
        break;

    default:
        printf("Operator is not Correct");
        //break;

    }

    return 0;
}
