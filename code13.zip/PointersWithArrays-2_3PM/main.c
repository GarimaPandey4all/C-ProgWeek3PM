#include <stdio.h>
#include <stdlib.h>

int main()
{
    int values[10], i;

    int *valuesptr =  NULL;

    valuesptr = values; //&values[0];

    printf("Enter values in an Array[10]");
    for(i=0; i<10; i++)
    {
        scanf("%d", valuesptr + i); //Example of Arithmetic Pointer
    }


    for(i=0; i<10; i++)
    {
        printf("Values in Array are: %d\n", *valuesptr);
        valuesptr++;
    }

    return 0;
}
