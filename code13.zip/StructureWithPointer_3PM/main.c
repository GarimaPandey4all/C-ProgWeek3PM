#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int Day;
    int Month;
    int Year;
}date, *dateptr;

//struct Date date, *dateptr;


int main()
{
    dateptr = &date;

    (*dateptr).Day= 2;
    dateptr->Month= 3;
    dateptr->Year= 2020;

    printf("Day %d - Month %d - Year %d", (*dateptr).Day, dateptr->Month, dateptr->Year);

    return 0;
}
