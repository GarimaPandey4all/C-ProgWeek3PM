#include <stdio.h>
#include <stdlib.h>

/*

    string compare= Same = 0
                    Greater = 1
                    Less than = -1

                    abc , abe= 1


*/


int main()
{

    char str1[10];
    char str2[10];

    printf("Enter Str1:");
    gets(str1);

    printf("Enter Str2:");
    gets(str2);

    if(strcmp(str1, str2)==0)
        printf("You entered the same string");

    else
        printf("Not the same strings");

    return 0;
}
