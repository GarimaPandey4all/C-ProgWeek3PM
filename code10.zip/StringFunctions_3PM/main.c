#include <stdio.h>
#include <stdlib.h>

/*
    String Predefined Functions:

    1. strlen()
    2. strcmp()
    3. strcpy()
    4. strlwr()
    5. strupr()
    6. strcat()

*/

int main()
{
    char Firstname[10];
    char Lastname[10];

    printf("Enter your FirstName:");
    gets(Firstname);

    printf("Enter your LastName:");
    gets(Lastname);

    printf("Length of FirstName is:%d\n", strlen(Firstname));

    printf("Length of LastName is:%d", strlen(Lastname));

    return 0;
}
