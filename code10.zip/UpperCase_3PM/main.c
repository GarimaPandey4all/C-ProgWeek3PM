#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[20];

    printf("Enter Str1:");
    gets(str1);

    printf("String is:%s", strupr(str1));

    return 0;
}
