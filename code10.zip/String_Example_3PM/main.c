#include <stdio.h>
#include <stdlib.h>

/*
    String- not available in c

    Character of Arrays: String in C

*/


int main()
{
    char name[20];

    printf("Enter your name:");
    gets(name);
    //scanf("%s", &name);

    puts(name);
    //printf("%s", name);
    return 0;
}
