#include <stdio.h>
#include <stdlib.h>


/*
        1. argc = Argument Count = 6
        2. argv[] = Argument vector=

        int main(program name, garima, hemant, vansh, 10, 19)

*/

int main(int argc, char *argv[])
{
    int i;
    for(i=0; i<argc; i++)
    {
        printf("Arguments are: %s\n", argv[i]);
    }

    return 0;
}
