#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum Week {Monday=10, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today;

    Today = Sunday;

    printf("Today is:%i", Today);

    return 0;
}
