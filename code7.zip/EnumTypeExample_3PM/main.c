#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum gender {male, female};

    enum gender mygender;

    mygender = male;

    enum gender anothergender;

    anothergender = female;

    printf("Gender 1: %d\n", mygender);

    printf("Gender 2: %d", anothergender);

    return 0;
}
