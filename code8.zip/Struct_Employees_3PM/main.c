#include <stdio.h>
#include <stdlib.h>

struct Employee
{
    char Emp_Name;
    int Salary;
    int Age;
    int Emp_Id;
    char Emp_Gender;
};

struct Employee Emp1;

int main()
{
    Emp1.Age=32;
    Emp1.Emp_Gender='M';
    Emp1.Emp_Name='G';
    Emp1.Salary=50000;
    Emp1.Emp_Id=11;

    printf("Details of Employee");
    printf("Name of Employee is:%c\n", Emp1.Emp_Name);
    printf("Age of Employee is: %d\n", Emp1.Age);
    printf("Gender of Employee is: %c\n", Emp1.Emp_Gender);
    printf("Salary of Employee is: %d\n", Emp1.Salary);
    printf("Emp Id of Employee is: %d\n", Emp1.Emp_Id);

    printf("Size of Emp1:%d", sizeof(Emp1));
    printf("Size of Char:%d", sizeof(char));

    return 0;
}
