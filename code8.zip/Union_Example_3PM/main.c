#include <stdio.h>
#include <stdlib.h>

union Data
{
    int i;
    int b;
    int c;
};

union Data data;

int main()
{

    data.i=30;
    printf("I is:%d\n", data.i);

    data.b=60;
    printf("I is:%d\n", data.b);

    data.c=90;
    printf("I is:%d", data.c);

    return 0;
}
