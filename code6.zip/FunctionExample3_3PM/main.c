#include <stdio.h>
#include <stdlib.h>

//Function with arguments and without return value

void Sum(int, int);

int main()
{
    int x, y;
    Sum(x, y);

    return 0;
}

void Sum(int a, int b)
{
    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);
   printf("Sum is: %d", a+b);
}
