#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Loops

    //for Loop

    //for(initialization; condition; incre/decre)

    int n, index=1;

  printf("Enter any number to print the Table:");
    scanf("%d", &n);
//
//    for(index=1; index<=10;index++)
//        printf("%d * %d = %d\n", n, index, index * n);

    //While Loop

    //initialization

    //while(condition)
    //incre/decre

//    int x;
//
//    x=1;
//
//    while(x<=10){
//        printf("X is:%d\n", x);
//        x++;
//    }

    do{
         printf("%d * %d = %d\n", n, index, n * index);
         index++;
    }while(index<=10);


    return 0;
}
