#include <stdio.h>
#include <stdlib.h>

/*
    Function has four types:

    1. Function without arguments and without return value
    2. Function with arguments and without return value
    2. Function without arguments and with return value
    2. Function with arguments and with return value

*/

//Function ProtoType
//Return_Type Function_Name() //Function Header
//{
//    Function Body
//}



int sum(); //Function Declaration

int main()
{
    sum(); //Function calling
    sum();
    sum();

    return 0;
}

int sum() //Function Definition
{
    int a, b, c;

    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

    c = a + b;

    printf("Sum is: %d", c);
}
