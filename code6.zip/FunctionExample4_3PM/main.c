#include <stdio.h>
#include <stdlib.h>

//Function without arguments and with return value

int Sum();

int main()
{
    int result;
    result =Sum();
    printf("Sum is: %d", result);

    return 0;
}

int Sum()
{
    int a, b;
    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

   return a+b;
}
