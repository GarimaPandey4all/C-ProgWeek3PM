#include <stdio.h>
#include <stdlib.h>

//Function without arguments and without return value

void Showdata();

int main()
{
    Showdata();

    return 0;
}

void Showdata()
{
    printf("Hello World");
}
