#include <stdio.h>
#include <stdlib.h>

//Function with arguments and with return value

int Sum(int, int);

int main()
{
    int result, x, y;
    result =Sum(x, y);
    printf("Sum is: %d", result);

    return 0;
}

int Sum(int a, int b)
{
    int c;
    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

    c = a+b;

    return c;
}
