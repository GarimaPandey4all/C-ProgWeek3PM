#include <stdio.h>
#include <stdlib.h>

int main()
{
//    int arr[4]; //array declaration
//    int arr2[4]= {3,4,5,6}; //traditional way
//
//    int arr3[4]= 19;
//    int arr4[3]= 40;
//
//    int arr5[4] = {[2]=5,1,6}; //Designated way
//
//    int arr6[4] = {2,3};
//
//    int arr7[][4] = {{2,3,4,5}, //Jagged Array
//                    {4,6,7,7}}

    //out of bounds array

    int arr1[]={5,6,7};

    //arr1[6] = 30; //out of bound

    printf("Arr[6] is:%d", arr1[6]);

    return 0;
}
