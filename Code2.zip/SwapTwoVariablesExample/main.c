#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a =3, b=5, temp;

    //Swapping using third variable

    temp = a;
    a = b;
    b = temp;

   printf("After swapping using third variable, the value of a and b is: %d and %d\n",a,b);


    //Swapping without using third variable: + and -

    a = a + b; // a= 8
    b = a - b; // b= 3
    a = a - b; // a= 5

    printf("After swapping without using third variable, the value of a and b is: %d and %d\n", a,b);

    //Swapping without using third variable: * and /

    a = a * b; // a= 15
    b = a / b; // b= 3
    a = a / b; // a= 5

    printf("After swapping without using third variable, the value of a and b is: %d and %d\n", a,b);

    return 0;
}
