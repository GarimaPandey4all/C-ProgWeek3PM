#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=10 , b=20, c=20, d=30;

    //Relational Operator

    if(b > a) //true
    {
        printf("b is greater than a\n");
    }

    if(a>=10)
    {
        printf("a is: %d\n", a);
    }

    if(a==10)
    {
        printf("a is: %d\n", a);
    }

    if(a != 11)
    {
        printf("a is: %d\n", a);
    }


    //Logical and Bitwise Operators

    if(!(a&&b)) // a = 10, b= 20, true
        printf("Result of a&&b is\n");

    if(c&d) // a=10, b=20, // a= 0000 1010,//  b= 0001 0100
    {
        printf("Result of a&b is\n");
    }

    // ~// 0=1, 1=0 //(a&&b)=true , !(a&&b)= false

    // Left and Right Shift

    int var = 5; // 0101= 10=1010 = 0001 0100=20

    printf("The left of variable var is: %d\n", var << 2);

    // 5 * 2^2=  20

    int var1 = 8; // 1000 = 0010

    printf("The right of variable var is: %d", var1 >> 2);

    // 8 / 2^2 = 2

    return 0;
}
