#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12 //Macros

int main()
{
    //const int months=12;

    //int array[MONTHS] = {31, 28, 30, 31, 30, 31, 30, 30, 30, 31, 30, 31};

    printf("1 Year= %d", MONTHS);
    return 0;
}
