#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c; //only declaration

    printf("Enter value for variable a: \n");
    scanf("%d", &a);

    printf("Enter value for variable b: \n");
    scanf("%d", &b);

    //Addition

    c = a+b;

    printf("Addition of Two Numbers is: %d \n", c);

    //Subtraction

    c= a-b;

    printf("Subtraction of Two Numbers is: %d \n", c);

    //Multiply

    c = a*b;

    printf("Multiply of Two Numbers is: %d \n", c);

    //Divide

    c = a/b;

    printf("Division of Two Numbers is: %d \n", c);

    //Modulus

    c = a%b; //give remainder

    printf("Modulus of Two Numbers is: %d \n", c);

    //Increment, pre or post

    printf("Pre-Increment of a is: %d \n", ++a); //a= 20, a=21

    //printf("Pre-Increment of a is: %d \n", a);

    printf("Post-Increment of a is: %d \n", a++); // a=21,

    // a=22;
    //printf("Pre-Increment of a is: %d \n", a);

    //Decrement , pre or post

    printf("Pre-Decrement of b is: %d \n", --b);

    printf("Post-Decrement of b is: %d \n", b--);

    printf("Post-Decrement of b is: %d \n", b);

    return 0;
}
